﻿#include<graphics.h>
#include<stdio.h>
#include<Windows.h>
#include <iostream>
#include<conio.h>
#include<time.h>
#include<stdlib.h>
#include<math.h>
#pragma comment(lib,"Winmm.lib")

#pragma warning(disable : 4996)
typedef struct course {
	int id;//课程编号
	char name[100];//课程名称
	int teacher_number;//教师工号
	char book[100];//教材
	int limit_number;//限制人数
	FILE* students;//学生名单
	int start_year, start_mounth, start_week;
	int end_year, end_mounth, end_week;
	int time[80];//上课时间
	int score;//学分
	int class_hours;//学时
	bool ismust;//是否必修
	int place;//上课地点
	FILE* introduction;//简介
} courses;
int sort_student(int type,courses sort[]);
int main() {

	courses sort[10];

	sort_student(1,sort);
	return 0;
}


int sort_student(int type,courses sort[]) {

	int total_course_num = 0;
	char tmp[2000];
	FILE* course_list;
	//数总共行数
	fopen_s(&course_list, "bin//course_list.txt", "r");
	while (fgets(tmp, 2000, course_list) != NULL)
	{
		total_course_num++;
	}
	fclose(course_list);
	printf("%d\n", total_course_num);







	courses* course_left_sort;
	course_left_sort = (courses*)malloc(total_course_num);


	FILE* course_f;
	int stu_id = 0;
	int *course_population =NULL;
	course_population = (int*)malloc(1000000 * sizeof(int));//因为课程号六位所以最大有1000000个班
	//for (int i = 0; i < 10000000000; i++) {

	//	course_population[i] = 0;
	//	//printf("第%d\n", i);
	//}



	//获取所有课程人数大小
	char file_id[100];
	for (int course_num = 100001; course_num < 100000 + total_course_num; course_num++) {
		sprintf_s(file_id, "bin\\course_students\\%d.txt", course_num);
		fopen_s(&course_f, file_id, "r");
		course_population[course_num] = 0;
		while(fscanf_s(course_f, ("%d"), &stu_id) != EOF)
		course_population[course_num]++;

		printf("%d\n",course_population[course_num]);
	}

	//将课程编号按人数大小排序
	int course_population_order[1000000];
	int bigger = course_population[100001];
	for (int course_num = 100001,i=0; course_num < 100000 + total_course_num; course_num++,i++) {
		if (course_population[course_num] >= bigger  && course_num == 100000 + total_course_num -1) {
			course_population_order[i] = course_num;
			bigger = course_population[course_num];
		}
	}
	for (int course_num = 100001, i = 0; course_num < 100000 + total_course_num; course_num++, i++) {
		printf("%d", course_population_order);
	}

//	fscanf(recordfile, ("%s  %d  %d seconds"), allhistory.ID, &allhistory.score, &allhistory.time);




	return 0;
}